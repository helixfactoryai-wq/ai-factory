# AI Factory

> Enterprise-grade platform for designing, auditing, improving, testing, and deploying AI systems.

![Phase](https://img.shields.io/badge/Phase-1-6366F1) ![Stack](https://img.shields.io/badge/Stack-React%2019%20%2B%20Vite%20%2B%20Supabase-0F172A)

---

## Tech Stack

| Layer       | Technology                      |
|-------------|---------------------------------|
| Framework   | React 19 + TypeScript           |
| Build       | Vite 5                          |
| Styling     | Tailwind CSS v3                 |
| Routing     | React Router v6                 |
| Data        | TanStack Query v5               |
| Backend     | Supabase (PostgreSQL)           |
| Icons       | Lucide React                    |

---

## Quick Start

### 1. Clone and install

```bash
git clone <your-repo-url>
cd ai-factory
npm install
```

### 2. Configure Supabase

```bash
cp .env.example .env.local
```

Edit `.env.local` and fill in your Supabase credentials:

```env
VITE_SUPABASE_URL=https://your-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```

Get these from: **Supabase Dashboard → Settings → API**

### 3. Run the database migration

Open the Supabase SQL Editor for your project and paste the contents of:

```
supabase/migrations/001_initial_schema.sql
```

This creates the `projects` table, enums, indexes, RLS policies, and optional seed data.

### 4. Start the dev server

```bash
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

---

## Project Structure

```
src/
├── components/
│   ├── layout/         # AppShell, Sidebar, Header
│   └── ui/             # Badges, Modal, Toast, Loading, EmptyState, ...
├── features/
│   ├── dashboard/      # DashboardPage
│   ├── projects/       # ProjectsPage, ProjectCard, ProjectForm
│   └── settings/       # SettingsPage
├── hooks/              # useProjects (TanStack Query hooks)
├── lib/                # supabase.ts, query-client.ts, database.types.ts
├── services/           # projects.service.ts (data access layer)
├── types/              # Shared TypeScript types
├── App.tsx             # Router + providers
├── main.tsx            # Entry point
└── index.css           # Tailwind + design tokens
```

---

## Phase 1 Features

- **Dashboard** — Project stats, pipeline status by stage, provider breakdown, recent projects list
- **Projects** — Full CRUD: create, edit, delete, search, filter by status, grid/list toggle
- **Settings** — Profile, database connection status, notification toggles, appearance options
- **Placeholder pages** — Prompt Builder, Templates, Audits, Deploy (Phase 2 & 3)

---

## Roadmap

| Phase | Features |
|-------|----------|
| ✅ 1 | Dashboard, Projects CRUD, Settings |
| 🔜 2 | Prompt Builder, Templates, Versioning |
| 🔜 3 | Audits, Deploy pipeline, Analytics |

---

## Database Schema

```sql
projects (
  id                uuid PRIMARY KEY,
  name              text NOT NULL,
  description       text,
  category          project_category,   -- Enterprise | Education | Business | Coding | Personal | Custom
  provider          project_provider,   -- ChatGPT | Claude | Gemini | DeepSeek | Kimi | OpenRouter | Other
  deployment_target deployment_target,  -- Supabase | Vercel | Railway | Cloud Run | Docker | Local
  status            project_status,     -- Idea | Development | Testing | Production
  version           text,               -- semver (e.g. 1.0.0)
  created_at        timestamptz,
  updated_at        timestamptz
)
```

---

## Scripts

```bash
npm run dev      # Start development server
npm run build    # Production build
npm run preview  # Preview production build
npm run lint     # ESLint
```

---

## License

MIT
