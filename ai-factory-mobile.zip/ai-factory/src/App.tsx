import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';

import { queryClient } from '@/lib/query-client';
import { ToastProvider } from '@/components/ui/Toast';
import { AppShell } from '@/components/layout/AppShell';
import { DashboardPage } from '@/features/dashboard/DashboardPage';
import { ProjectsPage } from '@/features/projects/ProjectsPage';
import { SettingsPage } from '@/features/settings/SettingsPage';
import { PlaceholderPage } from '@/components/ui/PlaceholderPage';

export function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ToastProvider>
        <BrowserRouter>
          <Routes>
            <Route element={<AppShell />}>
              <Route index element={<DashboardPage />} />
              <Route path="projects" element={<ProjectsPage />} />
              <Route
                path="prompt-builder"
                element={
                  <PlaceholderPage
                    title="Prompt Builder"
                    description="Design, iterate, and version-control your AI prompts with a visual editor, A/B testing, and performance metrics."
                    phase="Phase 2"
                  />
                }
              />
              <Route
                path="templates"
                element={
                  <PlaceholderPage
                    title="Templates"
                    description="Browse and fork pre-built AI system blueprints across categories. Share your own templates with the community."
                    phase="Phase 2"
                  />
                }
              />
              <Route
                path="audits"
                element={
                  <PlaceholderPage
                    title="Audits"
                    description="Automated evaluation pipelines that score your AI systems on accuracy, safety, latency, and cost."
                    phase="Phase 3"
                  />
                }
              />
              <Route
                path="deploy"
                element={
                  <PlaceholderPage
                    title="Deploy"
                    description="One-click deployment to Vercel, Railway, Cloud Run, or Docker. Monitor production metrics in real time."
                    phase="Phase 3"
                  />
                }
              />
              <Route path="settings" element={<SettingsPage />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Route>
          </Routes>
        </BrowserRouter>
        <ReactQueryDevtools initialIsOpen={false} />
      </ToastProvider>
    </QueryClientProvider>
  );
}
