// Sidebar is replaced by BottomNav on mobile.
// This file is kept for future desktop layout expansion.
export {};
