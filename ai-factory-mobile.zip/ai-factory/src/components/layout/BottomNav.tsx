import { NavLink, useLocation } from 'react-router-dom';
import { LayoutDashboard, FolderKanban, Settings } from 'lucide-react';

const NAV = [
  { label: 'Dashboard', href: '/',         icon: LayoutDashboard },
  { label: 'Projects',  href: '/projects', icon: FolderKanban },
  { label: 'Settings',  href: '/settings', icon: Settings },
];

export function BottomNav() {
  const location = useLocation();

  return (
    <nav className="fixed bottom-0 inset-x-0 z-50 bg-[#0F172A] border-t border-slate-700/60 flex items-center safe-area-bottom">
      {NAV.map(({ label, href, icon: Icon }) => {
        const active = href === '/' ? location.pathname === '/' : location.pathname.startsWith(href);
        return (
          <NavLink
            key={href}
            to={href}
            end={href === '/'}
            className="flex-1 flex flex-col items-center justify-center gap-1 py-2 min-h-[56px]"
          >
            <Icon
              className={`w-5 h-5 transition-colors ${active ? 'text-indigo-400' : 'text-slate-500'}`}
            />
            <span className={`text-[10px] font-medium transition-colors ${active ? 'text-indigo-400' : 'text-slate-500'}`}>
              {label}
            </span>
            {active && (
              <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-indigo-500 rounded-t-full" />
            )}
          </NavLink>
        );
      })}
    </nav>
  );
}
