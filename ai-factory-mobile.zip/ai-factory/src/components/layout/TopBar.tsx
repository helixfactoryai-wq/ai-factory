import { useLocation } from 'react-router-dom';
import { Zap } from 'lucide-react';

const PAGE_TITLES: Record<string, string> = {
  '/':               'Dashboard',
  '/projects':       'Projects',
  '/prompt-builder': 'Prompt Builder',
  '/templates':      'Templates',
  '/audits':         'Audits',
  '/deploy':         'Deploy',
  '/settings':       'Settings',
};

export function TopBar() {
  const location = useLocation();
  const key = Object.keys(PAGE_TITLES)
    .filter((k) => k !== '/')
    .find((k) => location.pathname.startsWith(k)) ?? '/';
  const title = PAGE_TITLES[key];

  return (
    <header className="sticky top-0 z-40 flex items-center justify-between px-4 h-14 bg-[#0F172A] border-b border-slate-700/60">
      <div className="flex items-center gap-2.5">
        <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-indigo-500 to-cyan-400 flex items-center justify-center glow-primary flex-shrink-0">
          <Zap className="w-3.5 h-3.5 text-white" />
        </div>
        <span className="text-sm font-bold text-slate-100">{title}</span>
      </div>
      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-cyan-400 flex items-center justify-center text-xs font-bold text-white">
        A
      </div>
    </header>
  );
}
