import type { ProjectStatus, ProjectCategory, ProjectProvider } from '@/types';

// ─── Status Badge ──────────────────────────────────────────────────────────────

const statusConfig: Record<ProjectStatus, { label: string; classes: string; dot: string }> = {
  Idea:        { label: 'Idea',        classes: 'bg-slate-500/20 text-slate-400 border-slate-500/30',        dot: 'bg-slate-400' },
  Development: { label: 'Development', classes: 'bg-blue-500/20 text-blue-400 border-blue-500/30',          dot: 'bg-blue-400' },
  Testing:     { label: 'Testing',     classes: 'bg-amber-500/20 text-amber-400 border-amber-500/30',       dot: 'bg-amber-400 animate-pulse' },
  Production:  { label: 'Production',  classes: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30', dot: 'bg-emerald-400 animate-pulse' },
};

interface StatusBadgeProps {
  status: ProjectStatus;
}

export function StatusBadge({ status }: StatusBadgeProps) {
  const cfg = statusConfig[status];
  return (
    <span className={`badge border ${cfg.classes}`}>
      <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${cfg.dot}`} />
      {cfg.label}
    </span>
  );
}

// ─── Category Badge ────────────────────────────────────────────────────────────

const categoryColors: Record<ProjectCategory, string> = {
  Enterprise: 'bg-violet-500/20 text-violet-400 border-violet-500/30',
  Education:  'bg-sky-500/20 text-sky-400 border-sky-500/30',
  Business:   'bg-indigo-500/20 text-indigo-400 border-indigo-500/30',
  Coding:     'bg-green-500/20 text-green-400 border-green-500/30',
  Personal:   'bg-pink-500/20 text-pink-400 border-pink-500/30',
  Custom:     'bg-orange-500/20 text-orange-400 border-orange-500/30',
};

interface CategoryBadgeProps {
  category: ProjectCategory;
}

export function CategoryBadge({ category }: CategoryBadgeProps) {
  return (
    <span className={`badge border ${categoryColors[category]}`}>
      {category}
    </span>
  );
}

// ─── Provider Badge ────────────────────────────────────────────────────────────

const providerColors: Record<ProjectProvider, string> = {
  ChatGPT:    'bg-teal-500/20 text-teal-400 border-teal-500/30',
  Claude:     'bg-orange-500/20 text-orange-400 border-orange-500/30',
  Gemini:     'bg-blue-500/20 text-blue-400 border-blue-500/30',
  DeepSeek:   'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
  Kimi:       'bg-purple-500/20 text-purple-400 border-purple-500/30',
  OpenRouter: 'bg-rose-500/20 text-rose-400 border-rose-500/30',
  Other:      'bg-slate-500/20 text-slate-400 border-slate-500/30',
};

interface ProviderBadgeProps {
  provider: ProjectProvider;
}

export function ProviderBadge({ provider }: ProviderBadgeProps) {
  return (
    <span className={`badge border ${providerColors[provider]}`}>
      {provider}
    </span>
  );
}
