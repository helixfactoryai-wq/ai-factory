import { useState } from 'react';
import type {
  Project,
  ProjectInsert,
  ProjectCategory,
  ProjectProvider,
  DeploymentTarget,
  ProjectStatus,
} from '@/types';
import { Spinner } from '@/components/ui/Loading';

const CATEGORIES: ProjectCategory[] = ['Enterprise', 'Education', 'Business', 'Coding', 'Personal', 'Custom'];
const PROVIDERS: ProjectProvider[] = ['ChatGPT', 'Claude', 'Gemini', 'DeepSeek', 'Kimi', 'OpenRouter', 'Other'];
const TARGETS: DeploymentTarget[] = ['Supabase', 'Vercel', 'Railway', 'Cloud Run', 'Docker', 'Local'];
const STATUSES: ProjectStatus[] = ['Idea', 'Development', 'Testing', 'Production'];

interface ProjectFormProps {
  initialValues?: Project;
  onSubmit: (values: ProjectInsert) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

interface FormValues {
  name: string;
  description: string;
  category: ProjectCategory;
  provider: ProjectProvider;
  deployment_target: DeploymentTarget;
  status: ProjectStatus;
  version: string;
}

interface FormErrors {
  name?: string;
  version?: string;
}

const defaultValues: FormValues = {
  name: '',
  description: '',
  category: 'Enterprise',
  provider: 'Claude',
  deployment_target: 'Vercel',
  status: 'Idea',
  version: '1.0.0',
};

function validate(values: FormValues): FormErrors {
  const errors: FormErrors = {};
  if (!values.name.trim()) errors.name = 'Project name is required.';
  else if (values.name.trim().length < 2) errors.name = 'Name must be at least 2 characters.';
  if (values.version && !/^\d+\.\d+\.\d+$/.test(values.version)) {
    errors.version = 'Version must follow semver format (e.g. 1.0.0).';
  }
  return errors;
}

function SelectField<T extends string>({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: T;
  onChange: (v: T) => void;
  options: T[];
}) {
  return (
    <div>
      <label className="label">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value as T)}
        className="input"
      >
        {options.map((opt) => (
          <option key={opt} value={opt}>
            {opt}
          </option>
        ))}
      </select>
    </div>
  );
}

export function ProjectForm({ initialValues, onSubmit, onCancel, isLoading }: ProjectFormProps) {
  const [values, setValues] = useState<FormValues>({
    name: initialValues?.name ?? defaultValues.name,
    description: initialValues?.description ?? defaultValues.description,
    category: (initialValues?.category as ProjectCategory) ?? defaultValues.category,
    provider: (initialValues?.provider as ProjectProvider) ?? defaultValues.provider,
    deployment_target: (initialValues?.deployment_target as DeploymentTarget) ?? defaultValues.deployment_target,
    status: (initialValues?.status as ProjectStatus) ?? defaultValues.status,
    version: initialValues?.version ?? defaultValues.version,
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [touched, setTouched] = useState<Partial<Record<keyof FormValues, boolean>>>({});

  const set = <K extends keyof FormValues>(key: K, val: FormValues[K]) => {
    setValues((prev) => ({ ...prev, [key]: val }));
    if (touched[key]) {
      const newErrors = validate({ ...values, [key]: val });
      setErrors(newErrors);
    }
  };

  const handleBlur = (key: keyof FormValues) => {
    setTouched((prev) => ({ ...prev, [key]: true }));
    setErrors(validate(values));
  };

  const handleSubmit = () => {
    const allTouched = Object.keys(values).reduce(
      (acc, k) => ({ ...acc, [k]: true }),
      {} as Record<keyof FormValues, boolean>
    );
    setTouched(allTouched);
    const errs = validate(values);
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    onSubmit({
      name: values.name.trim(),
      description: values.description.trim() || null,
      category: values.category,
      provider: values.provider,
      deployment_target: values.deployment_target,
      status: values.status,
      version: values.version || '1.0.0',
    });
  };

  return (
    <div className="space-y-5">
      {/* Name */}
      <div>
        <label className="label">
          Project Name <span className="text-red-400">*</span>
        </label>
        <input
          type="text"
          value={values.name}
          onChange={(e) => set('name', e.target.value)}
          onBlur={() => handleBlur('name')}
          placeholder="e.g. Customer Support Agent"
          className={`input ${touched.name && errors.name ? 'border-red-500 focus:ring-red-500/50' : ''}`}
          autoFocus
        />
        {touched.name && errors.name && (
          <p className="mt-1.5 text-xs text-red-400">{errors.name}</p>
        )}
      </div>

      {/* Description */}
      <div>
        <label className="label">Description</label>
        <textarea
          value={values.description}
          onChange={(e) => set('description', e.target.value)}
          placeholder="What does this AI system do?"
          rows={3}
          className="input resize-none"
        />
      </div>

      {/* Row: Category + Provider */}
      <div className="grid grid-cols-2 gap-4">
        <SelectField label="Category" value={values.category} onChange={(v) => set('category', v)} options={CATEGORIES} />
        <SelectField label="Provider" value={values.provider} onChange={(v) => set('provider', v)} options={PROVIDERS} />
      </div>

      {/* Row: Deployment Target + Status */}
      <div className="grid grid-cols-2 gap-4">
        <SelectField label="Deployment Target" value={values.deployment_target} onChange={(v) => set('deployment_target', v)} options={TARGETS} />
        <SelectField label="Status" value={values.status} onChange={(v) => set('status', v)} options={STATUSES} />
      </div>

      {/* Version */}
      <div>
        <label className="label">Version</label>
        <input
          type="text"
          value={values.version}
          onChange={(e) => set('version', e.target.value)}
          onBlur={() => handleBlur('version')}
          placeholder="1.0.0"
          className={`input font-mono ${touched.version && errors.version ? 'border-red-500 focus:ring-red-500/50' : ''}`}
        />
        {touched.version && errors.version && (
          <p className="mt-1.5 text-xs text-red-400">{errors.version}</p>
        )}
      </div>

      {/* Actions */}
      <div className="flex gap-3 pt-2 border-t border-slate-700/60">
        <button onClick={onCancel} className="btn-secondary flex-1" disabled={isLoading}>
          Cancel
        </button>
        <button onClick={handleSubmit} className="btn-primary flex-1 justify-center" disabled={isLoading}>
          {isLoading ? <Spinner size="sm" /> : initialValues ? 'Save changes' : 'Create project'}
        </button>
      </div>
    </div>
  );
}
