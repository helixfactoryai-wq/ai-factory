import { QueryClient } from '@tanstack/react-query';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: { staleTime: 1000 * 60 * 2, retry: 2, refetchOnWindowFocus: false },
    mutations: { retry: 0 },
  },
});
