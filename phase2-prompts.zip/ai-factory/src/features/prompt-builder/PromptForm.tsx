import { useState } from 'react';
import type { Prompt, PromptInsert, PromptModel } from '@/types/prompt';
import { Spinner } from '@/components/ui/Loading';

const MODELS: { value: PromptModel; label: string }[] = [
  { value: 'claude-sonnet', label: 'Claude Sonnet' },
  { value: 'claude-opus',   label: 'Claude Opus' },
  { value: 'claude-haiku',  label: 'Claude Haiku' },
  { value: 'gpt-4o',        label: 'GPT-4o' },
  { value: 'gpt-4-turbo',   label: 'GPT-4 Turbo' },
  { value: 'gpt-3.5-turbo', label: 'GPT-3.5 Turbo' },
  { value: 'gemini-pro',    label: 'Gemini Pro' },
  { value: 'gemini-flash',  label: 'Gemini Flash' },
  { value: 'deepseek-chat', label: 'DeepSeek Chat' },
  { value: 'other',         label: 'Other' },
];

// Rough token estimate (4 chars per token)
const estimateTokens = (text: string) => Math.ceil(text.length / 4);

interface Props {
  projectId: string;
  initialValues?: Prompt;
  onSubmit: (v: PromptInsert) => void;
  onCancel: () => void;
  isLoading?: boolean;
}

interface FormValues {
  name: string;
  content: string;
  model: PromptModel;
  notes: string;
}

function validate(v: FormValues): Partial<Record<keyof FormValues, string>> {
  const e: Partial<Record<keyof FormValues, string>> = {};
  if (!v.name.trim()) e.name = 'Name is required.';
  if (!v.content.trim()) e.content = 'Prompt content is required.';
  return e;
}

export function PromptForm({ projectId, initialValues, onSubmit, onCancel, isLoading }: Props) {
  const [values, setValues] = useState<FormValues>({
    name:    initialValues?.name    ?? '',
    content: initialValues?.content ?? '',
    model:   (initialValues?.model as PromptModel) ?? 'claude-sonnet',
    notes:   initialValues?.notes   ?? '',
  });
  const [errors, setErrors]   = useState<Partial<Record<keyof FormValues, string>>>({});
  const [touched, setTouched] = useState<Partial<Record<keyof FormValues, boolean>>>({});

  const set = <K extends keyof FormValues>(key: K, val: FormValues[K]) => {
    const next = { ...values, [key]: val };
    setValues(next);
    if (touched[key]) setErrors(validate(next));
  };

  const blur = (key: keyof FormValues) => {
    setTouched((t) => ({ ...t, [key]: true }));
    setErrors(validate(values));
  };

  const submit = () => {
    const allTouched = Object.keys(values).reduce(
      (a, k) => ({ ...a, [k]: true }),
      {} as Record<keyof FormValues, boolean>
    );
    setTouched(allTouched);
    const errs = validate(values);
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;
    onSubmit({
      project_id: projectId,
      name: values.name.trim(),
      content: values.content.trim(),
      model: values.model,
      notes: values.notes.trim() || null,
      version: initialValues ? initialValues.version + 1 : 1,
    });
  };

  const charCount = values.content.length;
  const tokenCount = estimateTokens(values.content);

  return (
    <div className="space-y-4">
      {/* Name */}
      <div>
        <label className="label">Prompt name <span className="text-red-400">*</span></label>
        <input
          type="text"
          value={values.name}
          onChange={(e) => set('name', e.target.value)}
          onBlur={() => blur('name')}
          placeholder="e.g. System prompt v1"
          className={`input ${touched.name && errors.name ? 'border-red-500' : ''}`}
          autoFocus
        />
        {touched.name && errors.name && (
          <p className="mt-1 text-xs text-red-400">{errors.name}</p>
        )}
      </div>

      {/* Model */}
      <div>
        <label className="label">Model</label>
        <select value={values.model} onChange={(e) => set('model', e.target.value as PromptModel)} className="input">
          {MODELS.map((m) => (
            <option key={m.value} value={m.value}>{m.label}</option>
          ))}
        </select>
      </div>

      {/* Content */}
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <label className="label mb-0">Content <span className="text-red-400">*</span></label>
          <div className="flex items-center gap-2 text-[10px] font-mono text-slate-500">
            <span>{charCount} chars</span>
            <span className="text-slate-700">·</span>
            <span>~{tokenCount} tokens</span>
          </div>
        </div>
        <textarea
          value={values.content}
          onChange={(e) => set('content', e.target.value)}
          onBlur={() => blur('content')}
          placeholder="You are a helpful assistant that..."
          rows={8}
          className={`input resize-none font-mono text-xs leading-relaxed ${touched.content && errors.content ? 'border-red-500' : ''}`}
          style={{ minHeight: '180px' }}
        />
        {touched.content && errors.content && (
          <p className="mt-1 text-xs text-red-400">{errors.content}</p>
        )}
      </div>

      {/* Notes */}
      <div>
        <label className="label">Notes <span className="text-slate-600 font-normal">(optional)</span></label>
        <textarea
          value={values.notes}
          onChange={(e) => set('notes', e.target.value)}
          placeholder="What changed in this version, known issues..."
          rows={2}
          className="input resize-none text-sm"
          style={{ minHeight: '64px' }}
        />
      </div>

      {/* Version info */}
      {initialValues && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-indigo-500/10 border border-indigo-500/20">
          <span className="text-xs text-indigo-400">
            Saving will create version {initialValues.version + 1}
            {' '}(currently v{initialValues.version})
          </span>
        </div>
      )}

      {/* Actions */}
      <div className="flex gap-3 pt-2 border-t border-slate-700/60">
        <button onClick={onCancel} className="btn-secondary flex-1 justify-center" disabled={isLoading}>
          Cancel
        </button>
        <button onClick={submit} className="btn-primary flex-1 justify-center" disabled={isLoading}>
          {isLoading ? <Spinner size="sm" /> : initialValues ? 'Save version' : 'Create prompt'}
        </button>
      </div>
    </div>
  );
}
