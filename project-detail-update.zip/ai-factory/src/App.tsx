import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from '@/lib/query-client';
import { ToastProvider } from '@/components/ui/Toast';
import { AppShell } from '@/components/layout/AppShell';
import { DashboardPage } from '@/features/dashboard/DashboardPage';
import { ProjectsPage } from '@/features/projects/ProjectsPage';
import { ProjectDetailPage } from '@/features/projects/ProjectDetailPage';
import { SettingsPage } from '@/features/settings/SettingsPage';
import { PlaceholderPage } from '@/components/ui/PlaceholderPage';

export function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ToastProvider>
        <BrowserRouter>
          <Routes>
            <Route element={<AppShell />}>
              <Route index element={<DashboardPage />} />
              <Route path="projects" element={<ProjectsPage />} />
              <Route path="projects/:id" element={<ProjectDetailPage />} />
              <Route path="prompt-builder" element={<PlaceholderPage title="Prompt Builder" description="Design, version, and A/B test your AI prompts with a visual editor." phase="Phase 2" />} />
              <Route path="templates"      element={<PlaceholderPage title="Templates"      description="Browse and fork pre-built AI system blueprints."                  phase="Phase 2" />} />
              <Route path="audits"         element={<PlaceholderPage title="Audits"         description="Automated evaluation pipelines for accuracy, safety, and cost."   phase="Phase 3" />} />
              <Route path="deploy"         element={<PlaceholderPage title="Deploy"         description="One-click deploy to Vercel, Railway, Cloud Run, or Docker."       phase="Phase 3" />} />
              <Route path="settings" element={<SettingsPage />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Route>
          </Routes>
        </BrowserRouter>
      </ToastProvider>
    </QueryClientProvider>
  );
}
