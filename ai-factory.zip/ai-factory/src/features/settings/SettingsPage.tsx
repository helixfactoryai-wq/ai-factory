import { useState } from 'react';
import {
  User,
  Database,
  Palette,
  Bell,
  Shield,
  ChevronRight,
  Check,
} from 'lucide-react';
import { useToast } from '@/components/ui/Toast';

interface SettingsSectionProps {
  icon: React.ElementType;
  title: string;
  description: string;
  children: React.ReactNode;
}

function SettingsSection({ icon: Icon, title, description, children }: SettingsSectionProps) {
  return (
    <div className="card overflow-hidden">
      <div className="px-6 py-5 border-b border-slate-700/60">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-primary-500/10 flex items-center justify-center">
            <Icon className="w-4 h-4 text-primary-400" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-slate-200">{title}</h3>
            <p className="text-xs text-slate-500 mt-0.5">{description}</p>
          </div>
        </div>
      </div>
      <div className="px-6 py-5 space-y-5">{children}</div>
    </div>
  );
}

function SettingsRow({
  label,
  description,
  children,
}: {
  label: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-6">
      <div>
        <p className="text-sm text-slate-200">{label}</p>
        {description && <p className="text-xs text-slate-500 mt-0.5">{description}</p>}
      </div>
      <div className="flex-shrink-0">{children}</div>
    </div>
  );
}

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={`
        relative w-9 h-5 rounded-full transition-colors duration-200
        ${checked ? 'bg-primary-600' : 'bg-space-500'}
        focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 focus:ring-offset-space-900
      `}
    >
      <span
        className={`
          absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white
          shadow transition-transform duration-200
          ${checked ? 'translate-x-4' : 'translate-x-0'}
        `}
      />
    </button>
  );
}

export function SettingsPage() {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);

  // Profile
  const [name, setName] = useState('Admin User');
  const [email, setEmail] = useState('admin@aifactory.dev');

  // Notifications
  const [emailNotifs, setEmailNotifs] = useState(true);
  const [deployAlerts, setDeployAlerts] = useState(true);
  const [auditSummaries, setAuditSummaries] = useState(false);

  // Appearance
  const [compactMode, setCompactMode] = useState(false);
  const [animations, setAnimations] = useState(true);

  const handleSave = async () => {
    setSaving(true);
    await new Promise((r) => setTimeout(r, 800));
    setSaving(false);
    toast('success', 'Settings saved');
  };

  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const isConnected = supabaseUrl && !supabaseUrl.includes('your-project');

  return (
    <div className="max-w-2xl space-y-6 animate-in">

      {/* Profile */}
      <SettingsSection icon={User} title="Profile" description="Your account details">
        <div>
          <label className="label">Display name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="input"
          />
        </div>
        <div>
          <label className="label">Email address</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="input"
          />
        </div>
        <div className="pt-1">
          <button onClick={handleSave} disabled={saving} className="btn-primary">
            {saving ? 'Saving...' : <><Check className="w-3.5 h-3.5" /> Save profile</>}
          </button>
        </div>
      </SettingsSection>

      {/* Database */}
      <SettingsSection icon={Database} title="Database" description="Supabase connection status">
        <div className="flex items-center justify-between p-4 rounded-lg bg-space-800 border border-slate-700/60">
          <div>
            <p className="text-sm font-medium text-slate-200">Supabase</p>
            <p className="text-xs text-slate-500 font-mono mt-0.5 truncate max-w-xs">
              {supabaseUrl ?? 'Not configured'}
            </p>
          </div>
          <span className={`badge border ${isConnected ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-red-500/10 text-red-400 border-red-500/30'}`}>
            <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${isConnected ? 'bg-emerald-400' : 'bg-red-400'}`} />
            {isConnected ? 'Connected' : 'Not configured'}
          </span>
        </div>
        {!isConnected && (
          <p className="text-xs text-slate-500">
            Copy <code className="font-mono text-primary-400">.env.example</code> to{' '}
            <code className="font-mono text-primary-400">.env.local</code> and add your Supabase credentials.
          </p>
        )}
      </SettingsSection>

      {/* Notifications */}
      <SettingsSection icon={Bell} title="Notifications" description="Control when you're alerted">
        <SettingsRow label="Email notifications" description="Receive updates by email">
          <Toggle checked={emailNotifs} onChange={setEmailNotifs} />
        </SettingsRow>
        <SettingsRow label="Deployment alerts" description="Notified when a project goes live">
          <Toggle checked={deployAlerts} onChange={setDeployAlerts} />
        </SettingsRow>
        <SettingsRow label="Audit summaries" description="Weekly AI audit digest">
          <Toggle checked={auditSummaries} onChange={setAuditSummaries} />
        </SettingsRow>
      </SettingsSection>

      {/* Appearance */}
      <SettingsSection icon={Palette} title="Appearance" description="Customize the interface">
        <SettingsRow label="Theme">
          <div className="flex items-center gap-1 p-1 bg-space-800 rounded-lg border border-slate-700/60">
            {['Dark', 'Light', 'System'].map((t) => (
              <button
                key={t}
                className={`px-2.5 py-1 rounded-md text-xs font-medium transition-all ${t === 'Dark' ? 'bg-primary-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
              >
                {t}
              </button>
            ))}
          </div>
        </SettingsRow>
        <SettingsRow label="Compact mode" description="Reduce spacing in lists and tables">
          <Toggle checked={compactMode} onChange={setCompactMode} />
        </SettingsRow>
        <SettingsRow label="Animations" description="Motion and transition effects">
          <Toggle checked={animations} onChange={setAnimations} />
        </SettingsRow>
      </SettingsSection>

      {/* Security */}
      <SettingsSection icon={Shield} title="Security" description="Access and authentication">
        {[
          { label: 'Change password', desc: 'Update your account password' },
          { label: 'Two-factor authentication', desc: 'Add an extra layer of security' },
          { label: 'Active sessions', desc: 'Manage devices with access' },
        ].map((item) => (
          <button
            key={item.label}
            className="w-full flex items-center justify-between py-1 text-left group"
          >
            <div>
              <p className="text-sm text-slate-200 group-hover:text-white transition-colors">{item.label}</p>
              <p className="text-xs text-slate-500">{item.desc}</p>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-slate-400 transition-colors" />
          </button>
        ))}
      </SettingsSection>
    </div>
  );
}
