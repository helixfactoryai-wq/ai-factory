import { useState, useMemo } from 'react';
import { Plus, Search, FolderKanban, LayoutGrid, List, Filter } from 'lucide-react';
import {
  useProjects,
  useCreateProject,
  useUpdateProject,
  useDeleteProject,
} from '@/hooks/useProjects';
import { ProjectCard } from './ProjectCard';
import { ProjectForm } from './ProjectForm';
import { Modal } from '@/components/ui/Modal';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { EmptyState } from '@/components/ui/EmptyState';
import { CardSkeleton } from '@/components/ui/Loading';
import { ErrorMessage } from '@/components/ui/ErrorMessage';
import { useToast } from '@/components/ui/Toast';
import type { Project, ProjectInsert, ProjectStatus } from '@/types';

const STATUS_FILTERS: Array<ProjectStatus | 'All'> = ['All', 'Idea', 'Development', 'Testing', 'Production'];

export function ProjectsPage() {
  const { data: projects, isLoading, error, refetch } = useProjects();
  const createProject = useCreateProject();
  const updateProject = useUpdateProject();
  const deleteProject = useDeleteProject();
  const { toast } = useToast();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<ProjectStatus | 'All'>('All');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const [createOpen, setCreateOpen] = useState(false);
  const [editTarget, setEditTarget] = useState<Project | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Project | null>(null);

  const filtered = useMemo(() => {
    if (!projects) return [];
    return projects.filter((p) => {
      const matchesSearch =
        !search ||
        p.name.toLowerCase().includes(search.toLowerCase()) ||
        (p.description ?? '').toLowerCase().includes(search.toLowerCase());
      const matchesStatus = statusFilter === 'All' || p.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [projects, search, statusFilter]);

  const handleCreate = async (values: ProjectInsert) => {
    try {
      await createProject.mutateAsync(values);
      setCreateOpen(false);
      toast('success', 'Project created', `"${values.name}" is ready.`);
    } catch {
      toast('error', 'Failed to create project', 'Check your connection and try again.');
    }
  };

  const handleEdit = async (values: ProjectInsert) => {
    if (!editTarget) return;
    try {
      await updateProject.mutateAsync({ id: editTarget.id, ...values });
      setEditTarget(null);
      toast('success', 'Project updated');
    } catch {
      toast('error', 'Failed to update project');
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteProject.mutateAsync(deleteTarget.id);
      setDeleteTarget(null);
      toast('success', 'Project deleted');
    } catch {
      toast('error', 'Failed to delete project');
    }
  };

  return (
    <div className="space-y-6">
      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search projects..."
            className="input pl-9"
          />
        </div>

        {/* Status filter */}
        <div className="flex items-center gap-1 p-1 bg-space-800 rounded-lg border border-slate-700/60 flex-shrink-0">
          <Filter className="w-3.5 h-3.5 text-slate-500 ml-1.5" />
          {STATUS_FILTERS.map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`
                px-2.5 py-1 rounded-md text-xs font-medium transition-all
                ${statusFilter === s
                  ? 'bg-primary-600 text-white'
                  : 'text-slate-400 hover:text-slate-200'}
              `}
            >
              {s}
            </button>
          ))}
        </div>

        {/* View toggle */}
        <div className="flex items-center p-1 bg-space-800 rounded-lg border border-slate-700/60">
          <button
            onClick={() => setViewMode('grid')}
            className={`p-1.5 rounded-md transition-all ${viewMode === 'grid' ? 'bg-primary-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`p-1.5 rounded-md transition-all ${viewMode === 'list' ? 'bg-primary-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <List className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Create button */}
        <button onClick={() => setCreateOpen(true)} className="btn-primary flex-shrink-0">
          <Plus className="w-4 h-4" /> New project
        </button>
      </div>

      {/* Result count */}
      {projects && projects.length > 0 && (
        <div className="flex items-center justify-between">
          <p className="text-xs text-slate-500">
            {filtered.length === projects.length
              ? `${projects.length} project${projects.length !== 1 ? 's' : ''}`
              : `${filtered.length} of ${projects.length} projects`}
          </p>
        </div>
      )}

      {/* States */}
      {isLoading && (
        <div className={`grid gap-4 ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 xl:grid-cols-3' : 'grid-cols-1'}`}>
          {Array.from({ length: 6 }).map((_, i) => <CardSkeleton key={i} />)}
        </div>
      )}

      {error && (
        <ErrorMessage
          message="Could not load projects. Check your Supabase connection."
          onRetry={() => refetch()}
        />
      )}

      {!isLoading && !error && filtered.length === 0 && (
        <>
          {search || statusFilter !== 'All' ? (
            <EmptyState
              icon={Search}
              title="No results found"
              description={`No projects match "${search || statusFilter}". Try a different search or filter.`}
              action={
                <button onClick={() => { setSearch(''); setStatusFilter('All'); }} className="btn-secondary">
                  Clear filters
                </button>
              }
            />
          ) : (
            <EmptyState
              icon={FolderKanban}
              title="No projects yet"
              description="Create your first AI project to get started building and deploying intelligent systems."
              action={
                <button onClick={() => setCreateOpen(true)} className="btn-primary">
                  <Plus className="w-4 h-4" /> Create your first project
                </button>
              }
            />
          )}
        </>
      )}

      {/* Grid / List */}
      {!isLoading && !error && filtered.length > 0 && (
        <div
          className={`grid gap-4 ${
            viewMode === 'grid'
              ? 'grid-cols-1 sm:grid-cols-2 xl:grid-cols-3'
              : 'grid-cols-1 max-w-3xl'
          }`}
        >
          {filtered.map((project) => (
            <ProjectCard
              key={project.id}
              project={project}
              onEdit={setEditTarget}
              onDelete={setDeleteTarget}
            />
          ))}
        </div>
      )}

      {/* Create Modal */}
      <Modal isOpen={createOpen} onClose={() => setCreateOpen(false)} title="New project">
        <ProjectForm
          onSubmit={handleCreate}
          onCancel={() => setCreateOpen(false)}
          isLoading={createProject.isPending}
        />
      </Modal>

      {/* Edit Modal */}
      <Modal isOpen={!!editTarget} onClose={() => setEditTarget(null)} title="Edit project">
        {editTarget && (
          <ProjectForm
            initialValues={editTarget}
            onSubmit={handleEdit}
            onCancel={() => setEditTarget(null)}
            isLoading={updateProject.isPending}
          />
        )}
      </Modal>

      {/* Delete Confirm */}
      <ConfirmDialog
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="Delete project?"
        description={`"${deleteTarget?.name}" will be permanently deleted. This cannot be undone.`}
        confirmLabel="Delete project"
        isLoading={deleteProject.isPending}
      />
    </div>
  );
}
