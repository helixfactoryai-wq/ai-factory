import { MoreVertical, Pencil, Trash2, GitBranch, Server, Calendar } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';
import type { Project } from '@/types';
import { StatusBadge, CategoryBadge, ProviderBadge } from '@/components/ui/Badges';

interface ProjectCardProps {
  project: Project;
  onEdit: (project: Project) => void;
  onDelete: (project: Project) => void;
}

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
  });
}

function ContextMenu({
  onEdit,
  onDelete,
  onClose,
}: {
  onEdit: () => void;
  onDelete: () => void;
  onClose: () => void;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [onClose]);

  return (
    <div
      ref={ref}
      className="absolute top-full right-0 mt-1 w-40 card border-slate-600/60 shadow-xl z-10 py-1 animate-in"
    >
      <button
        onClick={() => { onEdit(); onClose(); }}
        className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-slate-300 hover:text-slate-100 hover:bg-space-600 transition-colors"
      >
        <Pencil className="w-3.5 h-3.5" /> Edit project
      </button>
      <button
        onClick={() => { onDelete(); onClose(); }}
        className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-colors"
      >
        <Trash2 className="w-3.5 h-3.5" /> Delete
      </button>
    </div>
  );
}

export function ProjectCard({ project, onEdit, onDelete }: ProjectCardProps) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="card-hover p-5 flex flex-col gap-4 animate-in">
      {/* Header */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <h3 className="text-sm font-semibold text-slate-100 truncate leading-snug">
            {project.name}
          </h3>
          {project.description && (
            <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
              {project.description}
            </p>
          )}
        </div>
        <div className="relative flex-shrink-0">
          <button
            onClick={() => setMenuOpen((v) => !v)}
            className="p-1 rounded-md text-slate-500 hover:text-slate-300 hover:bg-space-600 transition-colors"
          >
            <MoreVertical className="w-4 h-4" />
          </button>
          {menuOpen && (
            <ContextMenu
              onEdit={() => onEdit(project)}
              onDelete={() => onDelete(project)}
              onClose={() => setMenuOpen(false)}
            />
          )}
        </div>
      </div>

      {/* Badges */}
      <div className="flex flex-wrap gap-1.5">
        <StatusBadge status={project.status as import('@/types').ProjectStatus} />
        <CategoryBadge category={project.category as import('@/types').ProjectCategory} />
        <ProviderBadge provider={project.provider as import('@/types').ProjectProvider} />
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-3 border-t border-slate-700/40 text-[11px] text-slate-500">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1">
            <GitBranch className="w-3 h-3" />
            v{project.version}
          </span>
          <span className="flex items-center gap-1">
            <Server className="w-3 h-3" />
            {project.deployment_target}
          </span>
        </div>
        <span className="flex items-center gap-1">
          <Calendar className="w-3 h-3" />
          {formatDate(project.created_at)}
        </span>
      </div>
    </div>
  );
}
