import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FolderKanban,
  Plus,
  TrendingUp,
  Lightbulb,
  Code2,
  FlaskConical,
  CheckCircle2,
  ArrowRight,
  Cpu,
  Layers,
} from 'lucide-react';
import { useProjects } from '@/hooks/useProjects';
import { StatusBadge, ProviderBadge } from '@/components/ui/Badges';
import { PageLoader } from '@/components/ui/Loading';
import { ErrorMessage } from '@/components/ui/ErrorMessage';
import { EmptyState } from '@/components/ui/EmptyState';
import type { Project, ProjectStatus, ProjectProvider } from '@/types';

// ─── Stat Card ────────────────────────────────────────────────────────────────

interface StatCardProps {
  label: string;
  value: number;
  icon: React.ElementType;
  color: string;
  bgColor: string;
  borderColor: string;
}

function StatCard({ label, value, icon: Icon, color, bgColor, borderColor }: StatCardProps) {
  return (
    <div className={`card border ${borderColor} p-5 flex items-center gap-4`}>
      <div className={`w-11 h-11 rounded-xl ${bgColor} flex items-center justify-center flex-shrink-0`}>
        <Icon className={`w-5 h-5 ${color}`} />
      </div>
      <div>
        <p className="text-2xl font-bold text-slate-100 leading-none">{value}</p>
        <p className="text-xs text-slate-500 mt-1">{label}</p>
      </div>
    </div>
  );
}

// ─── Provider breakdown ────────────────────────────────────────────────────────

function ProviderBar({ provider, count, total }: { provider: string; count: number; total: number }) {
  const pct = total > 0 ? Math.round((count / total) * 100) : 0;
  return (
    <div className="flex items-center gap-3">
      <span className="text-xs text-slate-400 w-20 flex-shrink-0 truncate">{provider}</span>
      <div className="flex-1 h-1.5 bg-space-600 rounded-full overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-primary-500 to-cyan-400 rounded-full transition-all duration-700"
          style={{ width: `${pct}%` }}
        />
      </div>
      <span className="text-xs font-mono text-slate-500 w-6 text-right">{count}</span>
    </div>
  );
}

// ─── Recent Project Row ────────────────────────────────────────────────────────

function RecentProjectRow({ project, onClick }: { project: Project; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="w-full flex items-center gap-4 px-4 py-3 hover:bg-space-600 transition-colors text-left rounded-lg group"
    >
      <div className="w-8 h-8 rounded-lg bg-primary-500/10 border border-primary-500/20 flex items-center justify-center flex-shrink-0">
        <Cpu className="w-3.5 h-3.5 text-primary-400" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-slate-200 truncate group-hover:text-white transition-colors">
          {project.name}
        </p>
        <p className="text-xs text-slate-500 truncate mt-0.5">
          {project.description ?? 'No description'}
        </p>
      </div>
      <div className="flex items-center gap-2 flex-shrink-0">
        <ProviderBadge provider={project.provider as ProjectProvider} />
        <StatusBadge status={project.status as ProjectStatus} />
        <ArrowRight className="w-3.5 h-3.5 text-slate-600 group-hover:text-slate-400 transition-colors" />
      </div>
    </button>
  );
}

// ─── Dashboard Page ────────────────────────────────────────────────────────────

export function DashboardPage() {
  const navigate = useNavigate();
  const { data: projects, isLoading, error, refetch } = useProjects();

  const stats = useMemo(() => {
    if (!projects) return null;
    const byStatus = projects.reduce((acc, p) => {
      acc[p.status as ProjectStatus] = (acc[p.status as ProjectStatus] ?? 0) + 1;
      return acc;
    }, {} as Partial<Record<ProjectStatus, number>>);

    const byProvider = projects.reduce((acc, p) => {
      acc[p.provider as ProjectProvider] = (acc[p.provider as ProjectProvider] ?? 0) + 1;
      return acc;
    }, {} as Partial<Record<ProjectProvider, number>>);

    const recent = [...projects]
      .sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime())
      .slice(0, 6);

    return { total: projects.length, byStatus, byProvider, recent };
  }, [projects]);

  if (isLoading) return <PageLoader />;
  if (error) return <ErrorMessage message="Could not load dashboard data." onRetry={() => refetch()} />;

  return (
    <div className="space-y-8 animate-in">
      {/* Hero greeting */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-100">
            Welcome to <span className="text-gradient">AI Factory</span>
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Design, audit, and ship AI systems with confidence.
          </p>
        </div>
        <button onClick={() => navigate('/projects')} className="btn-primary">
          <Plus className="w-4 h-4" /> New project
        </button>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          label="Total projects"
          value={stats?.total ?? 0}
          icon={FolderKanban}
          color="text-primary-400"
          bgColor="bg-primary-500/10"
          borderColor="border-primary-500/20"
        />
        <StatCard
          label="In production"
          value={stats?.byStatus?.Production ?? 0}
          icon={CheckCircle2}
          color="text-emerald-400"
          bgColor="bg-emerald-500/10"
          borderColor="border-emerald-500/20"
        />
        <StatCard
          label="In development"
          value={stats?.byStatus?.Development ?? 0}
          icon={Code2}
          color="text-blue-400"
          bgColor="bg-blue-500/10"
          borderColor="border-blue-500/20"
        />
        <StatCard
          label="Ideas"
          value={stats?.byStatus?.Idea ?? 0}
          icon={Lightbulb}
          color="text-amber-400"
          bgColor="bg-amber-500/10"
          borderColor="border-amber-500/20"
        />
      </div>

      {/* Main content grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Recent Projects — 2/3 width */}
        <div className="lg:col-span-2 card p-0 overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-slate-700/60">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-primary-400" />
              <h3 className="text-sm font-semibold text-slate-200">Recent projects</h3>
            </div>
            <button
              onClick={() => navigate('/projects')}
              className="text-xs text-primary-400 hover:text-primary-300 flex items-center gap-1 transition-colors"
            >
              View all <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          {stats && stats.recent.length > 0 ? (
            <div className="p-2">
              {stats.recent.map((p) => (
                <RecentProjectRow
                  key={p.id}
                  project={p}
                  onClick={() => navigate('/projects')}
                />
              ))}
            </div>
          ) : (
            <EmptyState
              icon={FolderKanban}
              title="No projects yet"
              description="Create your first project to start building."
              action={
                <button onClick={() => navigate('/projects')} className="btn-primary">
                  <Plus className="w-4 h-4" /> Create project
                </button>
              }
            />
          )}
        </div>

        {/* Right column */}
        <div className="space-y-6">
          {/* Provider breakdown */}
          <div className="card p-5">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-semibold text-slate-200">Provider breakdown</h3>
            </div>
            {stats && Object.keys(stats.byProvider).length > 0 ? (
              <div className="space-y-2.5">
                {Object.entries(stats.byProvider)
                  .sort(([, a], [, b]) => (b ?? 0) - (a ?? 0))
                  .map(([provider, count]) => (
                    <ProviderBar
                      key={provider}
                      provider={provider}
                      count={count ?? 0}
                      total={stats.total}
                    />
                  ))}
              </div>
            ) : (
              <p className="text-xs text-slate-600 text-center py-4">No data yet</p>
            )}
          </div>

          {/* Status breakdown */}
          <div className="card p-5">
            <div className="flex items-center gap-2 mb-4">
              <FlaskConical className="w-4 h-4 text-violet-400" />
              <h3 className="text-sm font-semibold text-slate-200">Pipeline status</h3>
            </div>
            <div className="space-y-2.5">
              {(['Idea', 'Development', 'Testing', 'Production'] as ProjectStatus[]).map((status) => {
                const count = stats?.byStatus?.[status] ?? 0;
                const total = stats?.total ?? 0;
                const pct = total > 0 ? Math.round((count / total) * 100) : 0;
                const colors: Record<ProjectStatus, string> = {
                  Idea: 'bg-slate-400',
                  Development: 'bg-blue-400',
                  Testing: 'bg-amber-400',
                  Production: 'bg-emerald-400',
                };
                return (
                  <div key={status} className="flex items-center gap-3">
                    <span className="text-xs text-slate-400 w-20 flex-shrink-0">{status}</span>
                    <div className="flex-1 h-1.5 bg-space-600 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-700 ${colors[status]}`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <span className="text-xs font-mono text-slate-500 w-6 text-right">{count}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
