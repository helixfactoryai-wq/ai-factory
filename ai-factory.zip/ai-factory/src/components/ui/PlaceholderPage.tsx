import { Construction, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface PlaceholderPageProps {
  title: string;
  description: string;
  phase?: string;
}

export function PlaceholderPage({
  title,
  description,
  phase = 'Phase 2',
}: PlaceholderPageProps) {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col items-center justify-center min-h-[500px] gap-6 animate-in">
      {/* Icon */}
      <div className="relative">
        <div className="w-20 h-20 rounded-2xl bg-space-700 border border-slate-700/60 flex items-center justify-center">
          <Construction className="w-8 h-8 text-primary-400" />
        </div>
        <span className="absolute -top-2 -right-2 text-[10px] font-mono font-bold bg-primary-600 text-white px-2 py-0.5 rounded-full">
          {phase}
        </span>
      </div>

      {/* Text */}
      <div className="text-center max-w-md">
        <h2 className="text-xl font-bold text-slate-100 mb-2">{title}</h2>
        <p className="text-sm text-slate-500 leading-relaxed">{description}</p>
      </div>

      {/* Roadmap teaser */}
      <div className="card p-5 max-w-sm w-full">
        <p className="text-xs font-mono text-slate-500 uppercase tracking-widest mb-3">
          Coming in {phase}
        </p>
        <div className="space-y-2">
          {['Design', 'Build', 'Test', 'Deploy'].map((step, i) => (
            <div key={step} className="flex items-center gap-3">
              <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0 ${i === 0 ? 'bg-primary-500 text-white' : 'bg-space-600 text-slate-500'}`}>
                {i + 1}
              </div>
              <div className={`flex-1 h-0.5 ${i === 0 ? 'bg-gradient-to-r from-primary-500 to-transparent' : 'bg-space-600'}`} />
              <span className={`text-xs ${i === 0 ? 'text-primary-400' : 'text-slate-600'}`}>{step}</span>
            </div>
          ))}
        </div>
      </div>

      <button onClick={() => navigate('/')} className="btn-secondary">
        <ArrowLeft className="w-4 h-4" /> Back to Dashboard
      </button>
    </div>
  );
}
