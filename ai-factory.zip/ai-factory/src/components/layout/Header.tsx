import { useLocation } from 'react-router-dom';
import { Bell, Search } from 'lucide-react';

const PAGE_TITLES: Record<string, { title: string; subtitle: string }> = {
  '/':               { title: 'Dashboard',      subtitle: 'Overview of your AI projects' },
  '/projects':       { title: 'Projects',        subtitle: 'Manage and track all AI systems' },
  '/prompt-builder': { title: 'Prompt Builder',  subtitle: 'Design and iterate on prompts' },
  '/templates':      { title: 'Templates',       subtitle: 'Reusable AI system blueprints' },
  '/audits':         { title: 'Audits',          subtitle: 'Review and evaluate AI outputs' },
  '/deploy':         { title: 'Deploy',          subtitle: 'Ship AI systems to production' },
  '/settings':       { title: 'Settings',        subtitle: 'Configure your workspace' },
};

export function Header() {
  const location = useLocation();

  // Match by prefix for nested routes
  const pageKey = Object.keys(PAGE_TITLES)
    .filter((k) => k !== '/')
    .find((k) => location.pathname.startsWith(k)) ?? '/';

  const page = PAGE_TITLES[pageKey] ?? PAGE_TITLES['/'];

  return (
    <header className="h-14 flex items-center justify-between px-6 border-b border-slate-700/60 bg-space-800/50 backdrop-blur-xs flex-shrink-0">
      {/* Page identity */}
      <div className="flex items-center gap-3">
        <div>
          <h2 className="text-sm font-semibold text-slate-100 leading-none">{page.title}</h2>
          <p className="text-xs text-slate-500 mt-0.5">{page.subtitle}</p>
        </div>
      </div>

      {/* Right actions */}
      <div className="flex items-center gap-2">
        <button className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-space-600 transition-colors">
          <Search className="w-4 h-4" />
        </button>
        <button className="p-2 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-space-600 transition-colors relative">
          <Bell className="w-4 h-4" />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-primary-400 rounded-full" />
        </button>
        <div className="w-px h-5 bg-slate-700 mx-1" />
        <div className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-space-600 transition-colors cursor-pointer">
          <div className="w-6 h-6 rounded-full bg-gradient-to-br from-primary-500 to-cyan-400 flex items-center justify-center text-[10px] font-bold text-white">
            A
          </div>
          <span className="text-xs text-slate-300 font-medium">Admin</span>
        </div>
      </div>
    </header>
  );
}
