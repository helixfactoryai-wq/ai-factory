import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  FolderKanban,
  Wand2,
  BookTemplate,
  ShieldCheck,
  Rocket,
  Settings,
  Zap,
} from 'lucide-react';

interface NavItem {
  label: string;
  href: string;
  icon: React.ElementType;
  placeholder?: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { label: 'Dashboard',       href: '/',               icon: LayoutDashboard },
  { label: 'Projects',        href: '/projects',        icon: FolderKanban },
  { label: 'Prompt Builder',  href: '/prompt-builder',  icon: Wand2,        placeholder: true },
  { label: 'Templates',       href: '/templates',       icon: BookTemplate, placeholder: true },
  { label: 'Audits',          href: '/audits',          icon: ShieldCheck,  placeholder: true },
  { label: 'Deploy',          href: '/deploy',          icon: Rocket,       placeholder: true },
];

// Assembly line "pipeline" — the signature element
function PipelineIndicator() {
  const steps = ['Build', 'Test', 'Audit', 'Deploy'];
  return (
    <div className="px-3 py-4 mx-2 rounded-xl bg-space-800 border border-slate-700/60">
      <p className="text-[10px] font-mono font-medium text-slate-500 uppercase tracking-widest mb-3">
        AI Pipeline
      </p>
      <div className="space-y-1.5">
        {steps.map((step, i) => (
          <div key={step} className="flex items-center gap-2">
            <div
              className={`
                w-1.5 h-1.5 rounded-full flex-shrink-0
                ${i === 0 ? 'bg-emerald-400 animate-pulse' :
                  i === 1 ? 'bg-amber-400' :
                  'bg-slate-600'}
              `}
            />
            <div className="flex-1 h-1 rounded-full bg-space-600 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-1000 ${
                  i === 0 ? 'w-3/4 bg-gradient-to-r from-primary-500 to-cyan-400' :
                  i === 1 ? 'w-1/3 bg-amber-500/70' :
                  'w-0'
                }`}
              />
            </div>
            <span className="text-[10px] text-slate-500 font-mono w-10 text-right">{step}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function Sidebar() {
  const location = useLocation();

  return (
    <aside className="w-60 flex-shrink-0 h-screen flex flex-col bg-space-800 border-r border-slate-700/60">
      {/* Logo */}
      <div className="px-5 py-5 border-b border-slate-700/60">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary-500 to-cyan-400 flex items-center justify-center flex-shrink-0 glow-primary">
            <Zap className="w-4 h-4 text-white" />
          </div>
          <div>
            <h1 className="text-sm font-bold text-slate-100 leading-none">AI Factory</h1>
            <p className="text-[10px] text-slate-500 mt-0.5 font-mono">v1.0.0 · Phase 1</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto px-2 py-3 space-y-0.5">
        <p className="px-3 py-1.5 text-[10px] font-mono font-medium text-slate-600 uppercase tracking-widest">
          Platform
        </p>
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = item.href === '/'
            ? location.pathname === '/'
            : location.pathname.startsWith(item.href);

          if (item.placeholder) {
            return (
              <div
                key={item.href}
                className="nav-item nav-item-disabled group"
                title="Coming soon"
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span className="flex-1">{item.label}</span>
                <span className="text-[9px] font-mono text-slate-700 bg-space-700 px-1.5 py-0.5 rounded border border-slate-700">
                  SOON
                </span>
              </div>
            );
          }

          return (
            <NavLink
              key={item.href}
              to={item.href}
              end={item.href === '/'}
              className={`nav-item ${isActive ? 'nav-item-active' : 'nav-item-inactive'}`}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              <span>{item.label}</span>
            </NavLink>
          );
        })}

        <div className="pt-3">
          <p className="px-3 py-1.5 text-[10px] font-mono font-medium text-slate-600 uppercase tracking-widest">
            Account
          </p>
          <NavLink
            to="/settings"
            className={({ isActive }) =>
              `nav-item ${isActive ? 'nav-item-active' : 'nav-item-inactive'}`
            }
          >
            <Settings className="w-4 h-4 flex-shrink-0" />
            <span>Settings</span>
          </NavLink>
        </div>
      </nav>

      {/* Pipeline indicator — signature design element */}
      <div className="pb-3">
        <PipelineIndicator />
      </div>
    </aside>
  );
}
